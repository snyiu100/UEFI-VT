Steps to run:
1. Open a command prompt window. 
	* It can be run using a normal user's admin rights
2. Change directory to <directory>\UEFI-VT\firmware-analyser
3. Run the following command:
	python romParser.py nvram <path to .rom/.bin sample>
4. Results can be found in the directory where your sample is found. The analysis can be found in the .log.txt file
	Sample output files: sample2.rom.nvar.log.txt
			     sample2.rom.nvar.nvram.bin
			     sample2.rom.nvar.nvram.dir and its contents