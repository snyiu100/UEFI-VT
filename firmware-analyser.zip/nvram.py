# Purpose: To facilitate the 'nvram' function in romParser.py --> Identify the type of the firmware
# Written by: Kezia Kew
# Date created: 3 May 2018

# Adapted from Chipsec

import os
import sys
import struct
from collections import namedtuple
import string
import binascii

from common import *
from efiParser import *


class FWType:
    EFI_FW_TYPE_UEFI      = 'uefi'
    EFI_FW_TYPE_UEFI_AUTH = 'uefi_auth'
#    EFI_FW_TYPE_WIN       = 'win'      # Windows 8 GetFirmwareEnvironmentVariable format
    EFI_FW_TYPE_VSS       = 'vss'       # NVRAM using format with '$VSS' signature
    EFI_FW_TYPE_VSS_AUTH  = 'vss_auth'  # NVRAM using format with '$VSS' signature with extra fields
                                        # See "A Tour Beyond BIOS Implementing UEFI Authenticated
                                        # Variables in SMM with EDKII"
    EFI_FW_TYPE_VSS_APPLE = 'vss_apple'
    EFI_FW_TYPE_NVAR      = 'nvar'      # 'NVAR' NVRAM format
    EFI_FW_TYPE_EVSA      = 'evsa'      # 'EVSA' NVRAM format


#################################################################################################
# EVSA Working methods
#################################################################################################
def FvSum16(buffer):
    sum16 = 0
    blen = len(buffer)/2
    i = 0
    while i < blen:
        el16 = ord(buffer[2*i]) | (ord(buffer[2*i+1]) << 8)
        sum16 = (sum16 + el16) & 0xffff
        i = i + 1
    return sum16

def FvChecksum16(buffer):
    return ((0x10000 - FvSum16(buffer)) & 0xffff)

VARIABLE_STORE_FV_GUID   = 'FFF12B8D-7696-4C8B-A985-2747075B4F50'
EFI_FIRMWARE_FILE_SYSTEM_GUID  = "7A9354D9-0468-444A-81CE-0BF617D890DF"
EFI_FIRMWARE_FILE_SYSTEM2_GUID = "8C8CE578-8A3D-4F1C-9935-896185C32DD3"
EFI_FIRMWARE_FILE_SYSTEM3_GUID = "5473C07A-3DCB-4DCA-BD6F-1E9689E7349A"
EFI_FS_GUIDS = [EFI_FIRMWARE_FILE_SYSTEM3_GUID, EFI_FIRMWARE_FILE_SYSTEM2_GUID, EFI_FIRMWARE_FILE_SYSTEM_GUID]
def ValidateFwVolumeHeader(ZeroVector, FsGuid, FvLength, Attributes, HeaderLength, Checksum, ExtHeaderOffset, Reserved, CalcSum, size):
    zero_vector = (ZeroVector == '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    fv_rsvd = (Reserved == 0)
    fs_guid = (FsGuid in (EFI_FS_GUIDS + [VARIABLE_STORE_FV_GUID]))
    fv_len = (FvLength <= size)
    fv_header_len = (ExtHeaderOffset < FvLength) and (HeaderLength < FvLength)
    #sum = (Checksum == CalcSum)
    return fv_rsvd and fv_len and fv_header_len

def NextFwVolume(buffer, off = 0):
    fof = off

    EFI_FIRMWARE_VOLUME_HEADER = "<16sIHH8sQIIHHHBB"
    vf_header_size = struct.calcsize(EFI_FIRMWARE_VOLUME_HEADER)
    EFI_FV_BLOCK_MAP_ENTRY = "<II"
    size = len(buffer)
    res = (None, None, None, None, None, None, None, None, None)

    while ((fof + vf_header_size) < size):
        fof =  buffer.find("_FVH", fof)
        if fof < 0x28: return res
        fof = fof - 0x28
        ZeroVector, FileSystemGuid0, FileSystemGuid1,FileSystemGuid2,FileSystemGuid3, \
          FvLength, Signature, Attributes, HeaderLength, Checksum, ExtHeaderOffset,    \
           Reserved, Revision = struct.unpack(EFI_FIRMWARE_VOLUME_HEADER, buffer[fof:fof+vf_header_size])
        '''
        print "\nFV volume offset: 0x%08X" % fof
        print "\tFvLength:         0x%08X" % FvLength
        print "\tAttributes:       0x%08X" % Attributes
        print "\tHeaderLength:     0x%04X" % HeaderLength
        print "\tChecksum:         0x%04X" % Checksum
        print "\tRevision:         0x%02X" % Revision
        print "\tExtHeaderOffset:  0x%02X" % ExtHeaderOffset
        print "\tReserved:         0x%02X" % Reserved
        '''
        #print "FFS Guid:     %s" % guid_str(FileSystemGuid0, FileSystemGuid1,FileSystemGuid2, FileSystemGuid3)
        #print "FV Checksum:  0x%04X (0x%04X)" % (Checksum, FvChecksum16(buffer[fof:fof+HeaderLength]))
        #'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
        fvh = struct.pack(EFI_FIRMWARE_VOLUME_HEADER, ZeroVector, \
                          FileSystemGuid0, FileSystemGuid1,FileSystemGuid2,FileSystemGuid3,     \
                          FvLength, Signature, Attributes, HeaderLength, 0, ExtHeaderOffset,    \
                          Reserved, Revision)

        if (len(fvh) < HeaderLength):
            #print "len(fvh)=%d, HeaderLength=%d" % (len(fvh), HeaderLength)
            tail = buffer[fof+len(fvh):fof+HeaderLength]
            fvh = fvh + tail

        CalcSum = FvChecksum16(fvh)
        FsGuid = guid_str(FileSystemGuid0, FileSystemGuid1,FileSystemGuid2,FileSystemGuid3)
        if (ValidateFwVolumeHeader(ZeroVector, FsGuid, FvLength, Attributes, HeaderLength, Checksum, ExtHeaderOffset, Reserved, CalcSum, size)):
            res = (fof, FsGuid, FvLength, Attributes, HeaderLength, Checksum, ExtHeaderOffset, buffer[fof:fof+FvLength], CalcSum)
            return res
        else:
            fof += 0x2C
    return res

#################################################################################################
# EFI Variable Methods --> EVSA
#################################################################################################
VARIABLE_STORE_SIGNATURE_EVSA = 'EVSA'
TLV_HEADER = "<BBH"
tlv_h_size = struct.calcsize(TLV_HEADER)
ADDITIONAL_NV_STORE_GUID = '00504624-8A59-4EEB-BD0F-6B36E96128E0'
def getNVstore_EVSA( nvram_buf ):
    l = (-1, -1, None)
    FvOffset, FsGuid, FvLength, FvAttributes, FvHeaderLength, FvChecksum, ExtHeaderOffset, FvImage, CalcSum = NextFwVolume(nvram_buf)
    while FvOffset != None:

        if (FsGuid == VARIABLE_STORE_FV_GUID):
            nvram_start = FvImage.find( VARIABLE_STORE_SIGNATURE_EVSA )

            if (nvram_start != -1) and (nvram_start >= tlv_h_size):
                nvram_start = nvram_start - tlv_h_size
                l = (FvOffset + nvram_start, FvLength - nvram_start, None)
                break

        if (FsGuid == ADDITIONAL_NV_STORE_GUID):
            nvram_start = FvImage.find( VARIABLE_STORE_SIGNATURE_EVSA )
            if (nvram_start != -1) and (nvram_start >= tlv_h_size):
                nvram_start = nvram_start - tlv_h_size
                l = (FvOffset + nvram_start, FvLength - nvram_start, None)
                
        FvOffset, FsGuid, FvLength, Attributes, HeaderLength, Checksum, ExtHeaderOffset, FvImage, CalcSum = NextFwVolume(nvram_buf, FvOffset+FvLength)
    return l

def EFIvar_EVSA(nvram_buf):
    image_size = len(nvram_buf)
    sn = 0
    EVSA_RECORD = "<IIII"
    evsa_rec_size = struct.calcsize(EVSA_RECORD)
    GUID_RECORD = "<HIHH8s"
    guid_rc_size = struct.calcsize(GUID_RECORD)
    fof = 0
    variables = dict()
    while fof < image_size:
        fof = nvram_buf.find("EVSA", fof)
        if fof == -1: break
        if fof < tlv_h_size:
            fof = fof + 4
            continue
        start = fof - tlv_h_size
        Tag0, Tag1, Size = struct.unpack(TLV_HEADER, nvram_buf[start: start + tlv_h_size])
        if Tag0 != 0xEC: # Wrong EVSA block
            fof = fof + 4
            continue
        value = nvram_buf[start + tlv_h_size:start + Size]
        Signature, Unkwn0, Length, Unkwn1 = struct.unpack(EVSA_RECORD, value)
        if start + Length > image_size: # Wrong EVSA record
            fof = fof + 4
            continue
        # NV storage EVSA found
        bof = 0
        guid_map = dict()
        var_list = list()
        value_list = dict()
        while (bof + tlv_h_size) < Length:
            Tag0, Tag1, Size = struct.unpack(TLV_HEADER, nvram_buf[start + bof: start + bof + tlv_h_size])
            if (Size < tlv_h_size):
                break
            value = nvram_buf[start + bof + tlv_h_size:start + bof + Size]
            bof = bof + Size
            if   (Tag0 == 0xED) or (Tag0 == 0xE1):  # guid
                GuidId, guid0, guid1, guid2, guid3 = struct.unpack(GUID_RECORD, value)
                g = guid_str(guid0, guid1, guid2, guid3)
                guid_map[GuidId] = g
            elif (Tag0 == 0xEE) or (Tag0 == 0xE2):  # var name
                VAR_NAME_RECORD = "<H%ds" % (Size - tlv_h_size - 2)
                VarId, Name = struct.unpack(VAR_NAME_RECORD, value)
                Name = unicode(Name, "utf-16-le")[:-1]
                var_list.append((Name, VarId, Tag0, Tag1))
            elif (Tag0 == 0xEF) or (Tag0 == 0xE3) or (Tag0 == 0x83):  # values
                VAR_VALUE_RECORD = "<HHI%ds" % (Size - tlv_h_size - 8)
                GuidId, VarId, Attributes, Data = struct.unpack(VAR_VALUE_RECORD, value)
                value_list[VarId] = (GuidId, Attributes, Data, Tag0, Tag1)
            elif not ((Tag0 == 0xff) and (Tag1 == 0xff) and (Size == 0xffff)):
                pass
        var_count = len(var_list)
        var_list.sort()
        var1 = {}
        for i in var_list:
            name = i[0]
            VarId = i[1]
            #NameTag0 = i[2]
            #NameTag1 = i[3]
            if VarId in value_list:
                var_value = value_list[VarId]
            else:
                #  Value not found for VarId
                continue
            GuidId = var_value[0]
            guid = "NONE"
            if GuidId not in guid_map:
                # Guid not found for GuidId
                pass
            else:
                guid = guid_map[GuidId]
            if name not in variables.keys():
                variables[name] = []
            #                       off,   buf,  hdr,  data,         guid, attrs
            variables[name].append((start, None, None, var_value[2], guid, var_value[1]))
        fof = fof + Length
    return variables

#################################################################################################
# NVAR Working methods
#################################################################################################
def FvSum8(buffer):
    sum8 = 0
    for b in buffer:
        sum8 = (sum8 + ord(b)) & 0xff
    return sum8

def FvChecksum8(buffer):
    return ((0x100 - FvSum8(buffer)) & 0xff)

EFI_FFS_FILE_HEADER = "<IHH8sHBB3sB"
file_header_size = struct.calcsize(EFI_FFS_FILE_HEADER)
EFI_FILE_MARKED_FOR_UPDATE    = 0x08
EFI_FILE_DELETED              = 0x10
EFI_FILE_HEADER_VALID         = 0x02
EFI_FILE_HEADER_INVALID       = 0x20
EFI_FILE_DATA_VALID           = 0x04
FFS_ATTRIB_CHECKSUM           = 0x40
FFS_FIXED_CHECKSUM            = 0xAA

def NextFwFile(FvImage, FvLength, fof, polarity):
    fof = align(fof, 8)
    cur_offset = fof
    next_offset = None
    res = None
    update_or_deleted = False

    if (fof + file_header_size) <= min(FvLength, len(FvImage)):

        if ('\xff\xff\xff\xff' == FvImage[fof+file_header_size-4:fof+file_header_size]):
            next_offset = fof + 8
            return (cur_offset, next_offset, None, None, None, None, None, None, None, None, update_or_deleted, None)

        Name0, Name1, Name2, Name3, IntegrityCheck, Type, Attributes, Size, State = struct.unpack(EFI_FFS_FILE_HEADER, FvImage[fof:fof+file_header_size])
        fsize = get_3b_size(Size)
        update_or_deleted = (bit_set(State, EFI_FILE_MARKED_FOR_UPDATE, polarity)) or (bit_set(State, EFI_FILE_DELETED, polarity))
        if   (not bit_set(State, EFI_FILE_HEADER_VALID, polarity))   or (bit_set(State, EFI_FILE_HEADER_INVALID, polarity)):
            next_offset = align(fof + 1, 8)

        elif (not bit_set(State, EFI_FILE_DATA_VALID, polarity)):
            next_offset = align(fof + 1, 8)

        elif fsize == 0:
            next_offset = align(fof + 1, 8)

        else:
            next_offset = fof + fsize
            next_offset = align(next_offset, 8)
            Name = guid_str(Name0, Name1, Name2, Name3)
            fheader = struct.pack(EFI_FFS_FILE_HEADER, Name0, Name1, Name2, Name3, 0, Type, Attributes, Size, 0)
            hsum = FvChecksum8(fheader)

            if (Attributes & FFS_ATTRIB_CHECKSUM):
                fsum = FvChecksum8(FvImage[fof+file_header_size:fof+fsize])
            else:
                fsum = FFS_FIXED_CHECKSUM

            CalcSum = (hsum | (fsum << 8))
            res = (cur_offset, next_offset, Name, Type, Attributes, State, IntegrityCheck, fsize, FvImage[fof:fof+fsize], file_header_size, update_or_deleted, CalcSum)
    if res is None: 
        return (cur_offset, next_offset, None, None, None, None, None, None, None, None, update_or_deleted, None)
    else:           
        return res

#################################################################################################
# EFI Variable Methods --> NVAR
#################################################################################################
EFI_FVB2_ERASE_POLARITY       = 0x00000800
EFI_FV_FILETYPE_RAW                     = 0x01
NVAR_NVRAM_FS_FILE       = "CEF5B9A3-476D-497F-9FDC-E98143E0422C"
def getNVstore_NVAR( nvram_buf ):
    l = (-1, -1, None)
    FvOffset, FsGuid, FvLength, FvAttributes, FvHeaderLength, FvChecksum, ExtHeaderOffset, FvImage, CalcSum = NextFwVolume(nvram_buf)
    if (FvOffset is None):
        return l
    if (FvOffset >= len(nvram_buf)):
        return l
    if (FvOffset + FvLength) > len(nvram_buf):
        FvLength = len(nvram_buf) - FvOffset
    while FvOffset != None:
        polarity = bit_set(FvAttributes, EFI_FVB2_ERASE_POLARITY)
        cur_offset, next_offset, Name, Type, Attributes, State, Checksum, Size, FileImage, HeaderSize, UD, fCalcSum = NextFwFile(FvImage, FvLength, FvHeaderLength, polarity)
        while next_offset != None:
            if (Type == EFI_FV_FILETYPE_RAW) and (Name == NVAR_NVRAM_FS_FILE):
                l = ((FvOffset + cur_offset + HeaderSize), Size - HeaderSize, None)
                if (not UD):
                    return l
            cur_offset, next_offset, Name, Type, Attributes, State, Checksum, Size, FileImage, HeaderSize, UD, fCalcSum = NextFwFile(FvImage, FvLength, next_offset, polarity)
        FvOffset, FsGuid, FvLength, Attributes, HeaderLength, Checksum, ExtHeaderOffset, FvImage, CalcSum = NextFwVolume(nvram_buf, FvOffset+FvLength)
    return l

def get_nvar_name(nvram, name_offset, isAscii):
    if isAscii:
        nend = nvram.find('\x00', name_offset)
        name_size = nend - name_offset + 1 # add trailing zero symbol
        name = nvram[name_offset:nend]
        return (name, name_size)
    else:
        nend = nvram.find('\x00\x00', name_offset)
        while (nend & 1) == 1:
            nend = nend + 1
            nend = nvram.find('\x00\x00', nend)
        name_size = nend - name_offset + 2 # add trailing zero symbol
        name = unicode(nvram[name_offset:nend], "utf-16-le")
        return (name, name_size)

NVAR_EFIvar_signature   = 'NVAR'

NVRAM_ATTR_RT         = 1
NVRAM_ATTR_DESC_ASCII = 2
NVRAM_ATTR_GUID       = 4
NVRAM_ATTR_DATA       = 8
NVRAM_ATTR_EXTHDR     = 0x10
NVRAM_ATTR_AUTHWR     = 0x40
NVRAM_ATTR_HER        = 0x20
NVRAM_ATTR_VLD        = 0x80

GUID = "<IHH8s"
guid_size = struct.calcsize(GUID)

# Variable Attributes
EFI_VARIABLE_NON_VOLATILE                          = 0x00000001 # Variable is non volatile
EFI_VARIABLE_BOOTSERVICE_ACCESS                    = 0x00000002 # Variable is boot time accessible
EFI_VARIABLE_RUNTIME_ACCESS                        = 0x00000004 # Variable is run-time accessible
EFI_VARIABLE_HARDWARE_ERROR_RECORD                 = 0x00000008 #
EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS            = 0x00000010 # Variable is authenticated
EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS = 0x00000020 # Variable is time based authenticated
EFI_VARIABLE_APPEND_WRITE                          = 0x00000040 # Variable allows append
UEFI23_1_AUTHENTICATED_VARIABLE_ATTRIBUTES         = (EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS | EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS)
def getEFIvariables_NVAR( nvram_buf ):
    
    start = nvram_buf.find( NVAR_EFIvar_signature )
    nvram_size = len(nvram_buf)
    EFI_HDR_NVAR = "<4sH3sB"
    nvar_size = struct.calcsize(EFI_HDR_NVAR)
    variables = dict()
    nof = 0 #start
    #   EMPTY = 0
    EMPTY = 0xffffffff
    while (nof+nvar_size) < nvram_size:
        start_id, size, next, attributes = struct.unpack(EFI_HDR_NVAR, nvram_buf[nof:nof+nvar_size])

        next = get_3b_size(next)
        valid = (bit_set(attributes, NVRAM_ATTR_VLD) and (not bit_set(attributes, NVRAM_ATTR_DATA)))

        if not valid:
            nof = nof + size
            # print 'kkcodes: not valid'     
            continue

        isvar = (start_id == NVAR_EFIvar_signature)
        if (not isvar) or (size == (EMPTY & 0xffff)): 
            # print 'kkcodes: not valid2'     
            break
        var_name_off = 1

        if bit_set(attributes, NVRAM_ATTR_GUID): # kkcodes: not accessed
            guid0, guid1, guid2, guid3 = struct.unpack(GUID, nvram_buf[nof+nvar_size:nof+nvar_size+guid_size])
            guid = guid_str(guid0, guid1, guid2, guid3)
            var_name_off = guid_size

        else: # kkcodes: accessed
            guid_idx = ord(nvram_buf[nof+nvar_size])
            guid0, guid1, guid2, guid3 = struct.unpack(GUID, nvram_buf[nvram_size - guid_size - guid_idx:nvram_size - guid_idx])
            guid = guid_str(guid0, guid1, guid2, guid3)

        name_size = 0
        name_offset = nof+nvar_size+var_name_off

        if not bit_set(attributes, NVRAM_ATTR_DATA):
            name, name_size = get_nvar_name(nvram_buf, name_offset, bit_set(attributes, NVRAM_ATTR_DESC_ASCII))

        esize = 0
        eattrs = 0

        if bit_set(attributes, NVRAM_ATTR_EXTHDR):
            esize, = struct.unpack("<H", nvram_buf[nof+size-2:nof+size])
            eattrs = ord(nvram_buf[nof+size-esize])

        attribs = EFI_VARIABLE_BOOTSERVICE_ACCESS

        attribs = attribs | EFI_VARIABLE_NON_VOLATILE

        if bit_set(attributes, NVRAM_ATTR_RT):  
            attribs = attribs | EFI_VARIABLE_RUNTIME_ACCESS

        if bit_set(attributes, NVRAM_ATTR_HER): 
            attribs = attribs | EFI_VARIABLE_HARDWARE_ERROR_RECORD

        if bit_set(attributes, NVRAM_ATTR_AUTHWR):
            if bit_set(eattrs, EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS):
                attribs = attribs | EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS

            if bit_set(eattrs, EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS):
                attribs = attribs | EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS
                
        # Get variable data
        lof = nof
        lnext = next
        lattributes = attributes
        lsize = size
        lesize = esize

        while lnext != (0xFFFFFF & EMPTY):
            lof = lof + lnext
            lstart_id, lsize, lnext, lattributes = struct.unpack(EFI_HDR_NVAR, nvram_buf[lof:lof+nvar_size])
            lnext = get_3b_size(lnext)

        dataof = lof + nvar_size

        if not bit_set(lattributes, NVRAM_ATTR_DATA):
            lnameof = 1
            if bit_set(lattributes, NVRAM_ATTR_GUID): lnameof = guid_size
            name_offset = lof+nvar_size+lnameof
            name, name_size = get_nvar_name(nvram_buf, name_offset, bit_set(attributes, NVRAM_ATTR_DESC_ASCII))
            dataof = name_offset + name_size

        if bit_set(lattributes, NVRAM_ATTR_EXTHDR):
            lesize, = struct.unpack("<H", nvram_buf[lof+lsize-2:lof+lsize])

        data = nvram_buf[dataof:lof+lsize-lesize]

        if name not in variables.keys():
            variables[name] = []

        if data.find(start_id)!=None: ## kknotes kkcodes: need to review placement
            logWriter ('================================================')
            logWriter ('NVAR Variables found in EFI Variable %s' % name)
            logWriter ('================================================')
            
            subVars = getNvarVariables(data)
            logWriter(subVars)

        # ===================== off, buf,  hdr,  data, guid, attrs
        variables[name].append((nof, None, None, data, guid, attribs))
            
        nof = nof + size

    return variables

#################################################################################################
# VSS Working methods 
#################################################################################################
def is_printable(seq):
    return set(seq).issubset(set(string.printable))

VSS_TYPES = (FWType.EFI_FW_TYPE_VSS, FWType.EFI_FW_TYPE_VSS_AUTH, FWType.EFI_FW_TYPE_VSS_APPLE)
def isCorrectVSStype(nvram_buf, vss_type):
    if (vss_type not in VSS_TYPES):
        return False

    buf_size = len(nvram_buf)
    start    = nvram_buf.find( VARIABLE_SIGNATURE_VSS )
    if (-1 == start):
        return False

    next_var = nvram_buf.find( VARIABLE_SIGNATURE_VSS, start+struct.calcsize( HDR_FMT_VSS ) ) # skip the minimun bytes required for the header
    if (-1 == next_var):
        next_var = buf_size

    buf_size -= start

    if   (vss_type == FWType.EFI_FW_TYPE_VSS):
        hdr_fmt  = HDR_FMT_VSS
        efi_var_hdr = EFI_HDR_VSS( *struct.unpack_from( hdr_fmt, nvram_buf[start:] ) )
    elif (vss_type == FWType.EFI_FW_TYPE_VSS_AUTH):
        hdr_fmt  = HDR_FMT_VSS_AUTH
        efi_var_hdr = EFI_HDR_VSS_AUTH( *struct.unpack_from( hdr_fmt, nvram_buf[start:] ) )
    elif (vss_type == FWType.EFI_FW_TYPE_VSS_APPLE):
        hdr_fmt  = HDR_FMT_VSS_APPLE
        efi_var_hdr = EFI_HDR_VSS_APPLE( *struct.unpack_from( hdr_fmt, nvram_buf[start:] ) )

    hdr_size = struct.calcsize( hdr_fmt )
    # check NameSize and DataSize
    name_offset = start + hdr_size
    if ((name_offset < next_var) and ((name_offset + efi_var_hdr.NameSize) < next_var)):
        valid_name = False
        if (efi_var_hdr.NameSize > 0):
            name = nvram_buf[name_offset: name_offset + efi_var_hdr.NameSize]
            try:
                name = unicode(name, "utf-16-le").split('\x00')[0]
                valid_name = is_printable(name) ## kkcodes: see what this is for
            except Exception as e:
                pass
        if (valid_name):
            end_var_offset = name_offset + efi_var_hdr.NameSize + efi_var_hdr.DataSize
            off_diff = next_var - end_var_offset
            if (off_diff == 0):
                return True
            elif (off_diff > 0):
                if (next_var == len(nvram_buf)) or (off_diff <= (MAX_VSS_VAR_ALIGNMENT - 1)):
                    return True
            else:
                if (next_var < len(nvram_buf)):
                    new_nex_var = nvram_buf.find(VARIABLE_SIGNATURE_VSS, next_var, next_var + len(VARIABLE_SIGNATURE_VSS) + (MAX_VSS_VAR_ALIGNMENT - 1))
                    if (new_nex_var <> -1):
                        return True

    return False


#################################################################################################
# UEFI | UEFI_AUTH [getNVStore] Working methods 
#################################################################################################
UEFI_VARIABLE_STORE_HEADER = "<IHH8sIBBHI"
UEFI_VARIABLE_STORE_HEADER_SIZE = struct.calcsize(UEFI_VARIABLE_STORE_HEADER)
VARIABLE_STORE_FORMATTED = 0x5a
VARIABLE_STORE_HEALTHY   = 0xfe
def _getNVstore_EFI( nvram_buf, efi_type ):
    l = (-1, -1, None)
    FvOffset = 0
    FvLength = 0
    while True:
        FvOffset, FsGuid, FvLength, Attributes, HeaderLength, Checksum, ExtHeaderOffset, FvImage, CalcSum = NextFwVolume(nvram_buf, FvOffset+FvLength)
        if (FvOffset == None): break
        if (FsGuid != VARIABLE_STORE_FV_GUID): continue
        nvram_start = HeaderLength
        StoreGuid0, StoreGuid1, StoreGuid2, StoreGuid03, Size, Format, State, R0, R1 = \
            struct.unpack(UEFI_VARIABLE_STORE_HEADER, FvImage[nvram_start:nvram_start + UEFI_VARIABLE_STORE_HEADER_SIZE])
        if ((Format == VARIABLE_STORE_FORMATTED) and (State == VARIABLE_STORE_HEALTHY)):
            if (isCorrectVSStype(FvImage[nvram_start:], efi_type)):
                l = (FvOffset + nvram_start, FvLength - nvram_start, None)
            break
    return l


def getNVstore_EFI( nvram_buf ):
    return _getNVstore_EFI( nvram_buf, FWType.EFI_FW_TYPE_VSS )

def getNVstore_EFI_AUTH( nvram_buf ):
    return _getNVstore_EFI( nvram_buf, FWType.EFI_FW_TYPE_VSS_AUTH )

#################################################################################################
# VSS | VSS AUTH | VSS APPLE [getNVStore] Working methods 
#################################################################################################
class VARIABLE_STORE_HEADER_VSS( namedtuple('VARIABLE_STORE_HEADER_VSS', 'Signature Size Format State Reserved Reserved1') ):
    __slots__ = ()
    def __str__(self):
        return """
            EFI Variable Store
            -----------------------------
            Signature : %s (0x%08X)
            Size      : 0x%08X bytes
            Format    : 0x%02X
            State     : 0x%02X
            Reserved  : 0x%04X
            Reserved1 : 0x%08X
            """ % ( struct.pack('=I',self.Signature), self.Signature, 
                    self.Size, 
                    self.Format, 
                    self.State, 
                    self.Reserved, 
                    self.Reserved1 )

VARIABLE_STORE_SIGNATURE_VSS  = '$VSS'
VARIABLE_STORE_HEADER_FMT_VSS = '=IIBBHI' # Signature is '$VSS'
def _getNVstore_VSS( nvram_buf, vss_type ):
    nvram_start = nvram_buf.find( VARIABLE_STORE_SIGNATURE_VSS )
    if -1 == nvram_start:
        return (-1, 0, None)
    buf = nvram_buf[nvram_start:]
    if (not isCorrectVSStype(buf, vss_type)):
        return (-1, 0, None)
    nvram_hdr = VARIABLE_STORE_HEADER_VSS( *struct.unpack_from( VARIABLE_STORE_HEADER_FMT_VSS, buf ) )
    return (nvram_start, nvram_hdr.Size, nvram_hdr)

def getNVstore_VSS( nvram_buf ):
    return _getNVstore_VSS(nvram_buf, FWType.EFI_FW_TYPE_VSS)

def getNVstore_VSS_AUTH( nvram_buf ):
    return _getNVstore_VSS(nvram_buf, FWType.EFI_FW_TYPE_VSS_AUTH)

def getNVstore_VSS_APPLE( nvram_buf):
    return _getNVstore_VSS(nvram_buf, FWType.EFI_FW_TYPE_VSS_APPLE)

#################################################################################################
# EFI Variable Methods [getEFIVar] --> UEFI & UEFI_AUTH | ALL VSS
#################################################################################################
class EFI_HDR_VSS( namedtuple('EFI_HDR_VSS', 
                              'StartId State Reserved Attributes NameSize DataSize guid0 guid1 guid2 guid3') ):
    __slots__ = ()
    def __str__(self):
        return """
            Header (VSS)
            ------------
            VendorGuid : {%08X-%04X-%04X-%04s-%06s}
            StartId    : 0x%04X
            State      : 0x%02X
            Reserved   : 0x%02X
            Attributes : 0x%08X
            NameSize   : 0x%08X
            DataSize   : 0x%08X
            """ % ( self.guid0, self.guid1, self.guid2, self.guid3[:2].encode('hex').upper(), self.guid3[-6::].encode('hex').upper(), 
                    self.StartId, 
                    self.State, 
                    self.Reserved, 
                    self.Attributes, 
                    self.NameSize, 
                    self.DataSize)

class EFI_HDR_VSS_AUTH( namedtuple('EFI_HDR_VSS_AUTH', 
                                   'StartId State Reserved Attributes MonotonicCount TimeStamp1 TimeStamp2 PubKeyIndex NameSize DataSize guid0 guid1 guid2 guid3') ):
    __slots__ = ()
    # if you don't re-define __str__ method, initialize is to None
    #__str__ = None
    def __str__(self):
        return """
            Header (VSS_AUTH)
            ----------------
            VendorGuid     : {%08X-%04X-%04X-%08X}
            StartId        : 0x%04X
            State          : 0x%02X
            Reserved       : 0x%02X
            Attributes     : 0x%08X
            MonotonicCount : 0x%016X
            TimeStamp1     : 0x%016X
            TimeStamp2     : 0x%016X
            PubKeyIndex    : 0x%08X
            NameSize       : 0x%08X
            DataSize       : 0x%08X
            """ % ( self.guid0, self.guid1, self.guid2, self.guid3[:2].encode('hex').upper(), self.guid3[-6::].encode('hex').upper(), 
                    self.StartId, 
                    self.State, 
                    self.Reserved, 
                    self.Attributes, 
                    self.MonotonicCount, 
                    self.TimeStamp1, 
                    self.TimeStamp2, 
                    self.PubKeyIndex, 
                    self.NameSize, 
                    self.DataSize )

class EFI_HDR_VSS_APPLE( namedtuple('EFI_HDR_VSS_APPLE', 
                                    'StartId State Reserved Attributes NameSize DataSize guid0 guid1 guid2 guid3 unknown') ):
    __slots__ = ()
    def __str__(self):
        return """
            Header (VSS_APPLE)
            ------------
            VendorGuid : {%08X-%04X-%04X-%04s-%06s}
            StartId    : 0x%04X
            State      : 0x%02X
            Reserved   : 0x%02X
            Attributes : 0x%08X
            NameSize   : 0x%08X
            DataSize   : 0x%08X
            Unknown    : 0x%08X
            """ % ( self.guid0, self.guid1, self.guid2, self.guid3[:2].encode('hex').upper(), self.guid3[-6::].encode('hex').upper(), 
                    self.StartId, 
                    self.State, 
                    self.Reserved, 
                    self.Attributes, 
                    self.NameSize, 
                    self.DataSize, 
                    self.unknown)

HDR_FMT_VSS                   = '<HBBIIIIHH8s'
HDR_FMT_VSS_AUTH  = '<HBBIQQQIIIIHH8s'
HDR_FMT_VSS_APPLE  = '<HBBIIIIHH8sI'
# Variable data start flag.
VARIABLE_DATA              = 0x55aa
VARIABLE_DATA_SIGNATURE    = struct.pack('=H', VARIABLE_DATA )
VARIABLE_SIGNATURE_VSS = VARIABLE_DATA_SIGNATURE
MAX_VSS_VAR_ALIGNMENT = 8
def _getEFIvariables_VSS( nvram_buf, _fwtype):
    variables = dict()
    nvsize = len(nvram_buf)
    if (FWType.EFI_FW_TYPE_VSS == _fwtype):
        hdr_fmt  = HDR_FMT_VSS
    elif (FWType.EFI_FW_TYPE_VSS_AUTH == _fwtype):
        hdr_fmt  = HDR_FMT_VSS_AUTH
    elif (FWType.EFI_FW_TYPE_VSS_APPLE == _fwtype):
        hdr_fmt  = HDR_FMT_VSS_APPLE
    else:
        return variables
    hdr_size = struct.calcsize( hdr_fmt )
    start    = nvram_buf.find( VARIABLE_SIGNATURE_VSS )
    if -1 == start:
        return variables

    while (start + hdr_size) < nvsize:
        if (FWType.EFI_FW_TYPE_VSS == _fwtype):
            efi_var_hdr = EFI_HDR_VSS( *struct.unpack_from( hdr_fmt, nvram_buf[start:] ) )
        elif (FWType.EFI_FW_TYPE_VSS_AUTH == _fwtype):
            efi_var_hdr = EFI_HDR_VSS_AUTH( *struct.unpack_from( hdr_fmt, nvram_buf[start:] ) )
        elif (FWType.EFI_FW_TYPE_VSS_APPLE == _fwtype):
            efi_var_hdr = EFI_HDR_VSS_APPLE( *struct.unpack_from( hdr_fmt, nvram_buf[start:] ) )

        if (efi_var_hdr.StartId != VARIABLE_DATA): break
        
        if ((efi_var_hdr.State == 0xff) and (efi_var_hdr.DataSize == 0xffffffff) and (efi_var_hdr.NameSize == 0xffffffff) and (efi_var_hdr.Attributes == 0xffffffff)):
             name_size = 0
             data_size = 0
             # just skip variable with empty name and data for now
             next_var_offset = nvram_buf.find( VARIABLE_SIGNATURE_VSS, start + hdr_size, start + hdr_size + len(VARIABLE_SIGNATURE_VSS) + (MAX_VSS_VAR_ALIGNMENT - 1))
             if (next_var_offset == -1) or (next_var_offset > nvsize):
                break
        else:
            name_size = efi_var_hdr.NameSize
            data_size = efi_var_hdr.DataSize
            efi_var_name = "<not defined>"

            end_var_offset = start + hdr_size + name_size + data_size
            # deal with different alignments (1-8)
            next_var_offset = nvram_buf.find( VARIABLE_SIGNATURE_VSS, end_var_offset, end_var_offset + len(VARIABLE_SIGNATURE_VSS) + (MAX_VSS_VAR_ALIGNMENT - 1))
            if (next_var_offset == -1) or (next_var_offset > nvsize):
                break
            efi_var_buf  = nvram_buf[ start : end_var_offset ]

            name_offset = hdr_size
            #if not IS_VARIABLE_ATTRIBUTE( efi_var_hdr.Attributes, EFI_VARIABLE_HARDWARE_ERROR_RECORD ):
            #efi_var_name = "".join( efi_var_buf[ NAME_OFFSET_IN_VAR_VSS : NAME_OFFSET_IN_VAR_VSS + name_size ] )
            Name = efi_var_buf[ name_offset : name_offset + name_size ]
            efi_var_name = unicode(Name, "utf-16-le").split('\x00')[0]

            efi_var_data = efi_var_buf[ name_offset + name_size : name_offset + name_size + data_size ]
            guid = guid_str(efi_var_hdr.guid0, efi_var_hdr.guid1, efi_var_hdr.guid2, efi_var_hdr.guid3)
            if efi_var_name not in variables.keys():
                variables[efi_var_name] = []
            #                                off,   buf,         hdr,         data,         guid, attrs
            variables[efi_var_name].append( (start, efi_var_buf, efi_var_hdr, efi_var_data, guid, efi_var_hdr.Attributes) )

        if start >= next_var_offset: break
        start = next_var_offset

    return variables

#################################################################################################
# EFI Variable Methods [getEFIVar] --> UEFI & UEFI_AUTH
#################################################################################################
def getEFIvariables_UEFI( nvram_buf ):
    #EFI_FW_TYPE_VSS       = 'vss'       # NVRAM using format with '$VSS' signature
    return _getEFIvariables_VSS(nvram_buf, FWType.EFI_FW_TYPE_VSS) 


def getEFIvariables_UEFI_AUTH( nvram_buf ):
    #EFI_FW_TYPE_VSS_AUTH  = 'vss_auth'  # NVRAM using format with '$VSS' signature with extra fields
    return _getEFIvariables_VSS(nvram_buf, FWType.EFI_FW_TYPE_VSS_AUTH)



#################################################################################################
# EFI Variable Methods [getEFIVar] --> VSS NVRAM | VSS AUTH NVRAM | VSS APPLE
#################################################################################################
def getEFIvariables_VSS( nvram_buf ):
    return _getEFIvariables_VSS( nvram_buf, FWType.EFI_FW_TYPE_VSS )

def getEFIvariables_VSS_AUTH( nvram_buf ):
    return _getEFIvariables_VSS( nvram_buf, FWType.EFI_FW_TYPE_VSS_AUTH )

def getEFIvariables_VSS_APPLE( nvram_buf ):
    return _getEFIvariables_VSS( nvram_buf, FWType.EFI_FW_TYPE_VSS_APPLE )

#################################################################################################
# EFI Variable Header Dictionary
#################################################################################################
EFI_VAR_DICT = {
    # EVSA --> When the format type is not known
    FWType.EFI_FW_TYPE_EVSA      : {
        'name' : 'EVSA',      
        'func_getefivariables' : EFIvar_EVSA,               
        'func_getnvstore' : getNVstore_EVSA 
        },
    
    # NVAR format
    FWType.EFI_FW_TYPE_NVAR      : {
        'name' : 'NVAR',      
        'func_getefivariables' : getEFIvariables_NVAR,      
        'func_getnvstore' : getNVstore_NVAR 
        },

    # UEFI
    FWType.EFI_FW_TYPE_UEFI      : {
        'name' : 'UEFI',      
        'func_getefivariables' : getEFIvariables_UEFI,      
        'func_getnvstore' : getNVstore_EFI  
        },
    FWType.EFI_FW_TYPE_UEFI_AUTH : {
        'name' : 'UEFI_AUTH', 
        'func_getefivariables' : getEFIvariables_UEFI_AUTH, 
        'func_getnvstore' : getNVstore_EFI_AUTH  
        },

    #Windows 8 NtEnumerateSystemEnvironmentValuesEx (infcls = 2)
    #FWType.EFI_FW_TYPE_WIN     : {
    #   'name' : 'WIN',     
    #   'func_getefivariables' : getEFIvariables_NtEnumerateSystemEnvironmentValuesEx2, 
    #   'func_getnvstore' : None },
    
    # $VSS NVRAM format
    FWType.EFI_FW_TYPE_VSS       : {
        'name' : 'VSS',       
        'func_getefivariables' : getEFIvariables_VSS,       
        'func_getnvstore' : getNVstore_VSS 
        },

    # $VSS Authenticated NVRAM format
    FWType.EFI_FW_TYPE_VSS_AUTH  : {
        'name' : 'VSS_AUTH',  
        'func_getefivariables' : getEFIvariables_VSS_AUTH,  
        'func_getnvstore' : getNVstore_VSS_AUTH 
        },

    # Apple $VSS formart
    FWType.EFI_FW_TYPE_VSS_APPLE : {
        'name' : 'VSS_APPLE', 
        'func_getefivariables' : getEFIvariables_VSS_APPLE, 
        'func_getnvstore' : getNVstore_VSS_APPLE 
        },
    
    }

## VSS: Variable Storage Space
