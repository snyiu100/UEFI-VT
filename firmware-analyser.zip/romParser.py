# Purpose: To parse the contents of the rom file to extract the NVRAM space &/or extract the efi modules
# --> either replaces python chipsec_util.py uefi nvram <.rom file> or 
# Written by: Kezia Kew
# Date created: 2 May 2018

# Usage: python 
# Example: >>python 

# Adapted from Chipsec / uefi-firmware-parser

import os
import sys
import struct
import binascii
import MySQLdb
from common import *
#import nvram
from nvram import *

# logFullText=''
# def logWriter(logText):
#     global logFullText

#     logFullText+=logText

# def logFileWriter(logFileName):
#     global logFullText
#     f = open (logFileName, 'a+')
#     f.write(logFullText)

# def fileWriter(logFileName, logText):
#     print logFileName
#     print logText
#     f = open (logFileName, 'a+')
#     f.write(logText+'\n')

#################################################################################################
# Working methods
#################################################################################################
fw_types = []
for i in [t for t in dir(FWType) if not callable(getattr(FWType, t))]:
    if not i.startswith('__'):
        fw_types.append( getattr(FWType, i) )

def identify_EFI_NVRAM( fileData ): # checks the EFI_VAR_DICT keys to ID which firmware type it is by alphabetical order; evsa/nvar/uefi/uefiauth
    for fw_type in fw_types:    #for t in uefi_platform.EFI_VAR_DICT.keys():   

        if EFI_VAR_DICT[ fw_type ]['func_getnvstore']:
            (offset, size, hdr) = EFI_VAR_DICT[ fw_type ]['func_getnvstore']( fileData )

            if offset != -1: # offset =-1 means not correct type; returns the correct fw type
                return fw_type

    return None

def set_FWType(efi_nvram_format ):
    if efi_nvram_format in fw_types:
        _FWType = efi_nvram_format
        return _FWType

def write_file( filename, buffer, append=False ):
    #with open( filename, 'wb' ) as f:
    #  f.write( buffer )
    #f.closed
    perm = 'ab' if append else 'wb'
    try:
        f = open(filename, perm)
    except:
        # print"Unable to open file '%.256s' for write access" % filename ##kkcodes: commented for cleanup
        return 0
    f.write( buffer )
    f.close()

    # print "[file] wrote %d bytes to '%.256s'" % ( len(buffer), filename ) ##kkcodes: commented for cleanup
    return True

# Variable State flags
VAR_IN_DELETED_TRANSITION     = 0xfe  # Variable is in obsolete transistion
VAR_DELETED                   = 0xfd  # Variable is obsolete
VAR_ADDED                     = 0x7f  # Variable has been completely added
#IS_VARIABLE_STATE(_c, _Mask)  (BOOLEAN) (((~_c) & (~_Mask)) != 0)
def IS_VARIABLE_STATE(_c, _Mask):
    return ( ( ((~_c)&0xFF) & ((~_Mask)&0xFF) ) != 0 )

# Variable Attributes
EFI_VARIABLE_NON_VOLATILE                          = 0x00000001 # Variable is non volatile
EFI_VARIABLE_BOOTSERVICE_ACCESS                    = 0x00000002 # Variable is boot time accessible
EFI_VARIABLE_RUNTIME_ACCESS                        = 0x00000004 # Variable is run-time accessible
EFI_VARIABLE_HARDWARE_ERROR_RECORD                 = 0x00000008 #
EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS            = 0x00000010 # Variable is authenticated
EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS = 0x00000020 # Variable is time based authenticated
EFI_VARIABLE_APPEND_WRITE                          = 0x00000040 # Variable allows append
UEFI23_1_AUTHENTICATED_VARIABLE_ATTRIBUTES         = (EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS | EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS)
def IS_VARIABLE_ATTRIBUTE(_c, _Mask):
    return ( (_c & _Mask) != 0 )

def get_attr_string( attr ): ## kknotes: may not be required; need to see usage/relevance
    attr_str = ' '
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_NON_VOLATILE ):
        attr_str = attr_str + 'NV+'
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_BOOTSERVICE_ACCESS ):
        attr_str = attr_str + 'BS+'
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_RUNTIME_ACCESS ):
        attr_str = attr_str + 'RT+'
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_HARDWARE_ERROR_RECORD ):
        attr_str = attr_str + 'HER+'
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_AUTHENTICATED_WRITE_ACCESS ):
        attr_str = attr_str + 'AWS+'
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS ):
        attr_str = attr_str + 'TBAWS+'
    if IS_VARIABLE_ATTRIBUTE( attr, EFI_VARIABLE_APPEND_WRITE ):
        attr_str = attr_str + 'AW+'
    return attr_str[:-1].lstrip()

def print_efi_variable( offset, efi_var_buf, EFI_var_header, efi_var_name, efi_var_data, efi_var_guid, efi_var_attributes , _FWType):
    # print '\n--------------------------------'
    # print 'EFI Variable (offset = 0x%x):' % offset
    # print '--------------------------------'
    logWriter ('================================')
    logWriter ('EFI Variable (offset = 0x%x):' % offset)
    logWriter ('================================')

    # Print Variable Name
    #print 'Name      : %s' % efi_var_name
    logWriter ('Name           : %s' % efi_var_name)

    # Print Variable GUID
    #print 'Guid      : %s' % efi_var_guid
    logWriter ('Guid           : %s' % efi_var_guid)

    # Print raw header content
    if EFI_var_header:
        if 'StartId' in EFI_var_header._fields:
            startID = getattr(EFI_var_header, 'StartId')
            logWriter ('StartId        : 0x%04X             | %s' % (startID, startID))

        if 'State' in EFI_var_header._fields:
            state = getattr(EFI_var_header, 'State')
            logWriter ('State          : 0x%02X               | %s' % (state, state))

            state_str = 'State          :'
            if IS_VARIABLE_STATE( state, VAR_IN_DELETED_TRANSITION ):
                state_str = state_str + ' IN_DELETED_TRANSITION +'
            if IS_VARIABLE_STATE( state, VAR_DELETED ):
                state_str = state_str + ' DELETED +'
            if IS_VARIABLE_STATE( state, VAR_ADDED ):
                state_str = state_str + ' ADDED +'
            logWriter (state_str)

        if 'Reserved' in EFI_var_header._fields:
            reserved = getattr(EFI_var_header, 'Reserved')
            logWriter ('Reserved       : 0x%02X               | %s' % (reserved, reserved))
        
        if 'MonotonicCount' in EFI_var_header._fields:
            monotonicCount = getattr(EFI_var_header, 'MonotonicCount')
            logWriter ('MonotonicCount : 0x%016X | %s' % (monotonicCount, monotonicCount))
        
        if 'TimeStamp1' in EFI_var_header._fields:
            timeStamp1 = getattr(EFI_var_header, 'TimeStamp1')
            logWriter ('TimeStamp1     : 0x%016X | %s' % (timeStamp1, timeStamp1))
        
        if 'TimeStamp2' in EFI_var_header._fields:
            timeStamp2 = getattr(EFI_var_header, 'TimeStamp2')
            logWriter ('TimeStamp2     : 0x%016X | %s' % (timeStamp2, timeStamp2))
        
        if 'PubKeyIndex' in EFI_var_header._fields:
            pubKeyIndex = getattr(EFI_var_header, 'PubKeyIndex')
            logWriter ('PubKeyIndex    : 0x%08X         | %s' % (pubKeyIndex, pubKeyIndex))
        
        if 'NameSize' in EFI_var_header._fields:
            nameSize = getattr(EFI_var_header, 'NameSize')
            logWriter ('NameSize       : 0x%08X         | %s' % (nameSize, nameSize))
        
        if 'DataSize' in EFI_var_header._fields:
            dataSize = getattr(EFI_var_header, 'DataSize')
            logWriter ('DataSize       : 0x%08X         | %s' % (dataSize, dataSize))

        if 'Attributes' in EFI_var_header._fields:
            attributes = getattr(EFI_var_header, 'Attributes')
            logWriter ('Attributes     : 0x%08X         | %s' % (attributes, attributes))
        
                                                            # kknotes: get_attr_string may not be required
    attr_str = ('Attributes     : 0x%X ( ' % efi_var_attributes) + get_attr_string( efi_var_attributes ) + ' )'
    #print attr_str
    logWriter (attr_str)

    # Print Variable Data
    #print 'Data:' 
    #print  efi_var_data # method: print_buffer logger.py
    logWriter ('Data:') 
    logWriter('----------------------HEX-----------------------|-----ASCII------|')
    #print_buffer( efi_var_data )
    print_buffer (efi_var_data) # method: print_buffer logger.py

def print_sorted_EFI_variables( variables , _FWType):
    sorted_names = sorted(variables.keys())
    for name in sorted_names:
        for rec in variables[name]:
            #                   off,    buf,     hdr,         data,   guid,   attrs
            print_efi_variable( rec[0], rec[1], rec[2], name, rec[3], rec[4], rec[5] , _FWType)

EFI_GLOBAL_VARIABLE_GUID         = '8BE4DF61-93CA-11D2-AA0D-00E098032B8C'
EFI_IMAGE_SECURITY_DATABASE_GUID = 'D719B2CB-3D3A-4596-A3BC-DAD00E67656F'
EFI_VAR_NAME_PK               = 'PK'
EFI_VAR_NAME_KEK              = 'KEK'
EFI_VAR_NAME_db               = 'db'
EFI_VAR_NAME_dbx              = 'dbx'
EFI_VAR_NAME_SecureBoot       = 'SecureBoot'
EFI_VAR_NAME_SetupMode        = 'SetupMode'
EFI_VAR_NAME_CustomMode       = 'CustomMode'
EFI_VAR_NAME_SignatureSupport = 'SignatureSupport'
EFI_VARIABLE_DICT = {
    EFI_VAR_NAME_PK              : EFI_GLOBAL_VARIABLE_GUID,
    EFI_VAR_NAME_KEK             : EFI_GLOBAL_VARIABLE_GUID,
    EFI_VAR_NAME_db              : EFI_IMAGE_SECURITY_DATABASE_GUID,
    EFI_VAR_NAME_dbx             : EFI_IMAGE_SECURITY_DATABASE_GUID,
    EFI_VAR_NAME_SecureBoot      : EFI_GLOBAL_VARIABLE_GUID,
    EFI_VAR_NAME_SetupMode       : EFI_GLOBAL_VARIABLE_GUID,
    EFI_VAR_NAME_CustomMode      : EFI_GLOBAL_VARIABLE_GUID,
    EFI_VAR_NAME_SignatureSupport: EFI_GLOBAL_VARIABLE_GUID
    }
SECURE_BOOT_KEY_VARIABLES  = (EFI_VAR_NAME_PK, EFI_VAR_NAME_KEK, EFI_VAR_NAME_db, EFI_VAR_NAME_dbx)
AUTHENTICATED_VARIABLES    = ('AuthVarKeyDatabase', 'certdb') + SECURE_BOOT_KEY_VARIABLES
def decode_EFI_variables( efi_vars, nvramFilePath , _FWType):
    # print decoded and sorted EFI variables into a log file
    print_sorted_EFI_variables( efi_vars , _FWType)

    # write each EFI variable into its own binary file
    for name in efi_vars.keys():
        n = 0
        for (off, buf, hdr, data, guid, attrs) in efi_vars[name]:
            # efi_vars[name] = (off, buf, hdr, data, guid, attrs)
            attr_str = get_attr_string( attrs )
            var_fname = os.path.join( nvramFilePath, '%s_%s_%s_%d.bin' % (name, guid, attr_str.strip(), n) ) # kkcodes: stddefaults file
            write_file( var_fname, data )

            #if name in SECURE_BOOT_VARIABLES:
            if name in AUTHENTICATED_VARIABLES: ## kknotes: not accessed in sample2-4, accessed in sample5
                logWriter ("AUTHENTICATED_VARIABLES exists")
                # parse_efivar_file( var_fname, data ) # kknotes: NEED TO CHANGE/ADD > current status: not added but should probably add

            n = n+1

def find_EFI_variable_store(fileData, _FWType ):
    if ( fileData is None ):
        # print 'fileData is None' ##kkcodes checkback
        return None

    offset       = 0
    size         = len(fileData)
    nvram_header = None

    if EFI_VAR_DICT[ _FWType ]['func_getnvstore']:
        (offset, size, nvram_header) = EFI_VAR_DICT[ _FWType ]['func_getnvstore'](fileData )
        if (-1 == offset):
            logWriter ("'func_getnvstore' is defined but could not find EFI NVRAM. Exiting..")
            return None
    else:
        logWriter ("[log] 'func_getnvstore' is not defined in EFI_VAR_DICT. Assuming start offset 0.." )

    if -1 == size: size = len(fileData)
    nvram_buf = fileData[ offset : offset + size ]

    logWriter( '[log] Found EFI NVRAM at offset 0x%08X' % offset )
    logWriter ('==================================================================')
    logWriter ('NVRAM: EFI Variable Store')
    logWriter ('==================================================================')

    if nvram_header: 
        print "nvramheader: %s" %nvram_header

    return nvram_buf


# extractNVRAM only
def parse_EFI_variables( romFileName, fileData, logFileName, _fw_type=None ):
    if _fw_type in fw_types:
        #print "[uefi] Using FW type (NVRAM format): %s" % _fw_type
        logWriter("[log] Using FW type (NVRAM format): %s" % _fw_type)
        _FWType = set_FWType( _fw_type )
    else:
        #print "Unrecognized FW type (NVRAM format) '%s'.." % _fw_type
        logWriter("[log] Unrecognized FW type (NVRAM format)") 
        return

    #print "[uefi] Searching for NVRAM in the binary.." 
    logWriter("[log] Searching for NVRAM in the binary.." )
    efi_vars_store = find_EFI_variable_store( fileData, _FWType )

    if efi_vars_store:
        nvramFileName = romFileName + '.nvram.bin'
        write_file( nvramFileName, efi_vars_store ) ## kknotes kkcodes: see to modify this method
        nvramFilePath = romFileName + '.nvram.dir'

        if not os.path.exists( nvramFilePath ):
            os.makedirs( nvramFilePath )

        #print "[uefi] Extracting EFI Variables in the NVRAM.." 
        logWriter("[log] Extracting EFI Variables in the NVRAM.." )

        #print "kkcodes: fw type is %s" % _FWType
        logWriter("[log] The firmware type is: %s" % _FWType)

        efi_vars = EFI_VAR_DICT[ _FWType ]['func_getefivariables']( efi_vars_store )
        decode_EFI_variables( efi_vars, nvramFilePath , _FWType)
    else:
        logWriter("[log] The NVRAM was not found")
        return False

    return True


#################################################################################################
# Main methods
#################################################################################################
# python chipsec_util.py decode C:\Users\user\Desktop\UEFI-VT\samples\sample4.rom nvar >> to extract contents of entire rom
# decode
def extractAll(filePath): ## Do later
    print "Not coded, work in progress"
    # uploadedFile = open(filePath,'rb')
    # fileData = uploadedFile.read()

    # print "in extractall"
    # fwtype = identify_EFI_NVRAM( fileData )
    # decode_uefi_region(_uefi, cur_dir, filename, fileData, fwtype)


    # # Original
    # logger.log( "Parsing EFI volumes from '%s'.." % filePath )
    # _orig_logname = self.logger.LOG_FILE_NAME
    # self.logger.set_log_file( filename + '.UEFI.lst' )
    # cur_dir = self.cs.helper.getcwd()
    # decode_uefi_region(_uefi, cur_dir, filename, fwtype)
    # self.logger.set_log_file( _orig_logname )

# python chipsec_util.py uefi nvram C:\Users\user\Desktop\UEFI-VT\samples\sample4.rom >> to extract nvar variable bin file
# nvram
def extractNVRAMOnly(filePath):
    uploadedFile = open(filePath,'rb')
    fileData = uploadedFile.read()
    # print "in extractnvramonly"

    fwtype = identify_EFI_NVRAM( fileData )
    if fwtype is None:
        logWriter ("Could not automatically identify EFI NVRAM type") 
        romFileName = filePath + '.noFW'
        
    #kkcodes: else
    else: 
        logWriter ("Identified EFI NVRAM type: %s" % fwtype)
        romFileName = filePath + '.' + fwtype

    logFileName = os.getcwd() + '\\' +romFileName + '.log.txt'


    parse_EFI_variables( romFileName, fileData, logFileName, fwtype)
    logFileWriter(logFileName)

    # try:
    #     parse_EFI_variables( romFileName, fileData, logFileName, fwtype)
    #     logFileWriter(logFileName)
    # except Exception as e:
    #     logWriter("There was an error in analysing the file")
    #     logWriter("Error: %s" % e)
    #     logFileWriter(logFileName)
        

# python romParser.py decode <.rom/.bin file> ==>> to extract contents of entire rom
# python romParser.py nvram <.rom/.bin file> ==>> to extract nvar variable bin file
# ========== Main Run Method ==========
if __name__ == "__main__": # Can look into using argparse for this instead
    print '\n'

    if len(sys.argv) <3 or len(sys.argv)>3:
        print "Please use the correct syntax"
        print "Usage: python nvarParser.py decode/nvram [ .bin file_path ]"
    else:
        filePath = sys.argv[2]
        checkFileValid = os.path.isfile(filePath)
        
        if checkFileValid==True:
            if sys.argv[1] == "decode":
                extractAll(filePath)

            elif sys.argv[1] == "nvram":
                extractNVRAMOnly(filePath)
                print "Completed, the output can be found in the directory your file is located in"
        else:
            print "Invalid filepath"
            print "Please use the correct syntax"
            print "Usage: romParser.py decode/nvram [.rom/.bin file]"
        
# kkcodes kknotes: may want to adapt _FWType to a global variable