# Purpose: To use the existing chipsec module to parse the extracted NVRAM .bin file to identify the EFI variables of the uploaded .rom file
# Written by: Kezia Kew
# Date created: 2 May 2018

# Usage: python nvarParser.py [ .bin file_path ]
# Example: >>python nvarParser.py C:\Users\user\Desktop\UEFI-VT\samples\sample4.rom.nvram.dir\StdDefaults_4599D26F-1A11-49B8-B91F-858745CFF824_NV+BS+RT_0.bin

# Adapted from Chipsec (https://github.com/chipsec/chipsec)
import string

fullLogText=''
def logWriter(logText):
    global fullLogText

    fullLogText+=logText+'\n'

def logFileWriter(logFileName):
    global fullLogText
    f = open (logFileName, 'a+')
    f.write(fullLogText)

def align(of, size):
    of = (((of + size - 1)/size) * size)
    return of

def get_3b_size(s):
    return (ord(s[0]) + (ord(s[1]) << 8) + (ord(s[2]) << 16))

def bit_set(value, mask, polarity = False):
    if polarity: value = ~value
    return ( (value & mask) == mask )

def guid_str(guid0, guid1, guid2, guid3):
    guid = "%08X-%04X-%04X-%04s-%06s" % (guid0, guid1, guid2, guid3[:2].encode('hex').upper(), guid3[-6::].encode('hex').upper())
    return guid

#prints the buffer
def print_buffer( arr, length = 16 ):  
    tmp=[]
    tmp_str=[]
    i=1
    for c in arr:
        tmp+=["%2.2x "%ord(c)]
        if (not c in string.printable) or (c in string.whitespace):
            ch = " "
        else:
            ch = ord(c)
        tmp_str+=["%c"%ch]
        if i%length==0:
            tmp+=["| "]
            tmp+=tmp_str
            tmp_s = "".join(tmp)
            logWriter(tmp_s )
            tmp_str=[]
            tmp=[]
        i+=1

    if 0 != len(arr)%length:
        tmp+=[ (length - len(arr)%length) * 3*" " ]
        tmp+=["| "]
        tmp+=tmp_str
        tmp_s = "".join(tmp)
        logWriter(tmp_s )

