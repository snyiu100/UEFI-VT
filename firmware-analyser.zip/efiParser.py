# Purpose: To parse the extracted NVRAM .bin file to identify the EFI variables of the uploaded .rom file
# Written by: Kezia Kew
# Date created: 13 April 2018
# Project: Firmware Analysis Portal Project - Part 2

# Usage: python efiParser.py [ file_path ]
# Example: >>python efiParser.py C:\Users\User\Desktop\demo.bin

import binascii
import os
import sys

# signature to 8 bit field = header
# signature = 4E564152
# size of record = 201A >> actual size = 1a20 (little endian)
# 'next' field = FFFFFF
# attribute = 83
# 8-bit field = 00
# name of var = 53746444656661756C7473 [StdDefaults]
'''def getNvarName(fileData): #getNvarVariable
    fileData = binascii.hexlify(fileData)
    fileDataLen = len(fileData)'''

def getNvarVariables(fileData):
    fileData = binascii.hexlify(fileData)
    fileDataLen = len(fileData)

    startIndex = 0
    counter = 0

    logger = ''

    while startIndex < fileDataLen:

        signature = "4e564152"
        signatureLen = 8
        signatureStartIndex = fileData.find(signature, startIndex)
        signatureEndIndex = signatureStartIndex+signatureLen
        #print "signatureStartIndex is: %s" % signatureStartIndex
        # logger += "signatureStartIndex is: %s" % signatureStartIndex

        if signatureStartIndex == -1:
            #print "No other NVAR variables, exiting..."
            # logger += "\nNo other NVAR variables, exiting..."
            break

        sizeLen = 4
        sizeStartIndex = signatureEndIndex
        sizeEndIndex = sizeStartIndex + sizeLen
        size = fileData[sizeStartIndex : sizeEndIndex]
        size = size[-2:] + size[:2] # change endian
        sizeDecimal = int(size, 16)
        #print "hex size is: %s" % size
        # logger += "\nhex size is: %s" % size
        #print "decimal size [hex pairs] is: %s" % sizeDecimal
        # logger += "\ndecimal size [hex pairs] is: %s" % sizeDecimal
        #print "decimal size [hex digit] is: %s" % str(sizeDecimal*2)
        # logger += "\ndecimal size [hex digit] is: %s" % str(sizeDecimal*2)
        
        nextLen = 6

        attributeLen = 2
        attributeStartIndex = sizeEndIndex + nextLen
        attributeEndIndex = attributeStartIndex + attributeLen
        attribute = fileData[attributeStartIndex : attributeEndIndex]
        #attribute = '0x' + attribute
        #print "hex attribute is: %s" % attribute
        # logger += "\nhex attribute is: %s" % attribute

        headerLen = 22

        nameFooter = '00'
        nameStartIndex = signatureStartIndex + headerLen
        nameEndIndex = fileData.find(nameFooter, nameStartIndex)
        # nameEndIndex = fileData.find('00', nameStartIndex)
        if (nameEndIndex %2 != 0):
            nameEndIndex = nameEndIndex + 1
        name = fileData[nameStartIndex : nameEndIndex]
        nameAscii = binascii.unhexlify(name)
        #print "hex name is: %s" % name
        # logger += "\nhex name is: %s" % name
        #print "ascii name is: %s" % nameAscii
        # logger += "\nascii name is: %s" % nameAscii


        empty = 'ffffffff'
        bodyStartIndex = nameEndIndex
        bodyEndIndex = fileData.find(signature, bodyStartIndex)
        #print "bodyEndIndex is: %s" % bodyEndIndex
        # logger += "\nbodyEndIndex is: %s" % bodyEndIndex

        if bodyEndIndex == -1: #last NVAR var
            bodyEndIndex = fileData.find(empty, bodyStartIndex)
            # print "bodyEndIndex is: %s" % bodyEndIndex
            # logger += "\nbodyEndIndex is: %s" % bodyEndIndex
        
        body = fileData[bodyStartIndex : bodyEndIndex]
        # bodyAscii = binascii.unhexlify(body)
        #print "hex body is: %s" % body
        # logger += "\nhex body is: %s" % body
        #print "ascii body is: %s" % bodyAscii ## some are only whitespaces

        startIndex = bodyEndIndex
        counter += 1
        #print "counter is %s" % counter
        # logger += "\ncounter is %s" % counter
        #print "============================="
        # logger += "\n=============================\n"


        logger +=   "SignatureStartIndex        :%s" % signatureStartIndex
        logger += "\nHex Size                   :%s" % size
        logger += "\nDecimal Size [hex pairs]   :%s" % sizeDecimal
        logger += "\nDecimal Size [hex digit]   :%s" % str(sizeDecimal*2)
        logger += "\nHex Attribute              :%s" % attribute
        logger += "\nHex Name                   :%s" % name
        logger += "\nAscii Name                 :%s" % nameAscii
        logger += "\nBodyEndIndex               :%s" % bodyEndIndex
        logger += "\nHex Body                   :\n%s" % body
        logger += "\nCounter                    :%s" % counter
        logger += "\n===========================================\n"
        
    return logger

# Can look into using argparse for this instead
if __name__ == "__main__":
    print "\r\n"    

    if len(sys.argv) == 2:
        filePath = sys.argv[1]
        checkFileValid = os.path.isfile(filePath)
        
        if checkFileValid==True:
            uploadedFile = open(filePath,'rb') #open file in Read mode and in binary format
            fileData = uploadedFile.read()
            uploadedFile.close()

            output = getNvarVariables(fileData)
            print output
        else:
            print "Invalid filepath"
            print "Please use the correct syntax"
            print "Usage: python efiParser.py [ file_path ]"
    else:
        print "Please use the correct syntax"
        print "Usage: python nvarParser.py decode/nvram [ .bin file_path ]"
    
# Usage: python efiParser.py [ file_path ]
