This is ripped out of UEFITool, https://github.com/LongSoft/UEFITool,
which is under the BSD license.  Note that this applies only to this
subdirectory.  I (James Mastros) hereby disclaim any and all copyright
interest in jmm.cpp (which consists mostly of bits of code copied from
elsewhere in uefitool.)


